/**
 * 
 */
/**
 * 
 */
module ProyectoParadigmas {
}